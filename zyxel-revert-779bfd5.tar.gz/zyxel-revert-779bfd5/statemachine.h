#ifndef _STATEMACHINE_H_
#define _STATEMACHINE_H_

int statemachine_read(int fd, void *privdata);

#endif /* _STATEMACHINE_H_ */
