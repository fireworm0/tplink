#ifndef _LZSC_H_
#define _LZSC_H_

int lzs_pack(void *src, int srcsize, void *dst, int dstsize);

#endif /* _LZSC_H_ */
