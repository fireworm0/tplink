#ifndef _SERIAL_H_
#define _SERIAL_H_

#include "context.h"

int serial_init(struct context *ctx, const char *device);

#endif /* _SERIAL_H_ */
